# Drawing data used in my machine learning course
Course Link: https://www.youtube.com/playlist?list=PLB0Tybl0UNfYe9aJXfWw-Dw_4VnFrqRC4

I will update this data from time to time [Last Update: 6.12.2022, when I recorded Phase 1 of the course]

You need to add the data to each package you use to follow along (P1 doesn't need it):
https://github.com/gniziemazity/ml-course 

The data you download here is in raw form and will be automatically processed when you install a package.
